# this_file: src/imgcolorshine/fast_numba/__init__.py
"""Numba-accelerated modules for imgcolorshine."""
